
package com.example.personalnotesreminder.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.personalnotesreminder.model.Note;

import java.util.List;

@Dao
public interface NoteDao {

    // Insert a new note
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Note note);

    // Update an existing note
    @Update
    void update(Note note);

    // Delete a note
    @Delete
    void delete(Note note);

    // Get all notes
    // Pinned notes appear first
    @Query("SELECT * FROM notes ORDER BY pinned DESC, createdDate DESC")
    LiveData<List<Note>> getAllNotes();

    // Search notes by title, description or category
    @Query("SELECT * FROM notes WHERE title LIKE '%' || :searchQuery || '%' " +
            "OR description LIKE '%' || :searchQuery || '%' " +
            "OR category LIKE '%' || :searchQuery || '%' " +
            "ORDER BY pinned DESC, createdDate DESC")
    LiveData<List<Note>> searchNotes(String searchQuery);

    // Get notes belonging to a particular category
    @Query("SELECT * FROM notes WHERE category = :category " +
            "ORDER BY pinned DESC, createdDate DESC")
    LiveData<List<Note>> getNotesByCategory(String category);

    // Delete all notes
    @Query("DELETE FROM notes")
    void deleteAllNotes();
}
