
package com.example.personalnotesreminder.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.personalnotesreminder.database.NoteDao;
import com.example.personalnotesreminder.database.NotesDatabase;
import com.example.personalnotesreminder.model.Note;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class NoteRepository {

    private final NoteDao noteDao;
    private final LiveData<List<Note>> allNotes;

    private final ExecutorService executorService =
            Executors.newSingleThreadExecutor();

    public NoteRepository(Application application) {

        NotesDatabase database =
                NotesDatabase.getDatabase(application);

        noteDao = database.noteDao();

        allNotes = noteDao.getAllNotes();
    }

    // Get all notes
    public LiveData<List<Note>> getAllNotes() {
        return allNotes;
    }

    // Search notes
    public LiveData<List<Note>> searchNotes(String query) {
        return noteDao.searchNotes(query);
    }

    // Filter notes by category
    public LiveData<List<Note>> getNotesByCategory(String category) {
        return noteDao.getNotesByCategory(category);
    }

    // Insert a note
    public void insert(Note note) {
        executorService.execute(() -> noteDao.insert(note));
    }

    // Update a note
    public void update(Note note) {
        executorService.execute(() -> noteDao.update(note));
    }

    // Delete a note
    public void delete(Note note) {
        executorService.execute(() -> noteDao.delete(note));
    }

    // Delete all notes
    public void deleteAllNotes() {
        executorService.execute(() -> noteDao.deleteAllNotes());
    }
}
