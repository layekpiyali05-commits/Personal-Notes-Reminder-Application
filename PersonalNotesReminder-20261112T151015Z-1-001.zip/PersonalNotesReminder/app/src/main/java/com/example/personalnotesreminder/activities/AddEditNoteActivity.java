
package com.example.personalnotesreminder.activities;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.personalnotesreminder.R;
import com.example.personalnotesreminder.model.Note;
import com.example.personalnotesreminder.notification.AlarmScheduler;
import com.example.personalnotesreminder.viewmodel.NoteViewModel;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddEditNoteActivity extends AppCompatActivity {

    private EditText edtTitle, edtDescription;
    private Spinner spinnerNoteCategory;
    private CheckBox checkPin, checkReminder;
    private Button btnSelectDate, btnSelectTime, btnSaveNote;
    private TextView txtReminderDateTime;

    private NoteViewModel noteViewModel;
    private Note existingNote;

    private Calendar reminderCalendar = Calendar.getInstance();

    private boolean dateSelected = false;
    private boolean timeSelected = false;

    private final String[] categories = {
            "Personal", "Study", "Work", "Shopping", "Other"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_note);

        initializeViews();

        noteViewModel = new ViewModelProvider(this)
                .get(NoteViewModel.class);

        setupCategorySpinner();

        // Check whether an existing note is being edited
        existingNote = (Note) getIntent()
                .getSerializableExtra("note");

        if (existingNote != null) {
            loadNoteData();
        }

        btnSelectDate.setOnClickListener(v -> selectDate());

        btnSelectTime.setOnClickListener(v -> selectTime());

        btnSaveNote.setOnClickListener(v -> saveNote());
    }

    // Initialize UI components
    private void initializeViews() {

        edtTitle = findViewById(R.id.edtTitle);
        edtDescription = findViewById(R.id.edtDescription);

        spinnerNoteCategory = findViewById(R.id.spinnerNoteCategory);

        checkPin = findViewById(R.id.checkPin);
        checkReminder = findViewById(R.id.checkReminder);

        btnSelectDate = findViewById(R.id.btnSelectDate);
        btnSelectTime = findViewById(R.id.btnSelectTime);
        btnSaveNote = findViewById(R.id.btnSaveNote);

        txtReminderDateTime = findViewById(R.id.txtReminderDateTime);
    }

    // Setup category dropdown
    private void setupCategorySpinner() {

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                categories
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerNoteCategory.setAdapter(adapter);
    }

    // Load existing note for editing
    private void loadNoteData() {

        edtTitle.setText(existingNote.getTitle());
        edtDescription.setText(existingNote.getDescription());

        checkPin.setChecked(existingNote.isPinned());
        checkReminder.setChecked(existingNote.isReminderEnabled());

        int categoryPosition = 0;

        for (int i = 0; i < categories.length; i++) {

            if (categories[i].equals(existingNote.getCategory())) {
                categoryPosition = i;
                break;
            }
        }

        spinnerNoteCategory.setSelection(categoryPosition);

        if (existingNote.isReminderEnabled()
                && existingNote.getReminderTime() > 0) {

            reminderCalendar.setTimeInMillis(
                    existingNote.getReminderTime()
            );

            dateSelected = true;
            timeSelected = true;

            updateReminderText();
        }
    }

    // Select reminder date
    private void selectDate() {

        int year = reminderCalendar.get(Calendar.YEAR);
        int month = reminderCalendar.get(Calendar.MONTH);
        int day = reminderCalendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {

                    reminderCalendar.set(
                            selectedYear,
                            selectedMonth,
                            selectedDay
                    );

                    dateSelected = true;
                    updateReminderText();
                },
                year,
                month,
                day
        );

        dialog.show();
    }

    // Select reminder time
    private void selectTime() {

        int hour = reminderCalendar.get(Calendar.HOUR_OF_DAY);
        int minute = reminderCalendar.get(Calendar.MINUTE);

        TimePickerDialog dialog = new TimePickerDialog(
                this,
                (view, selectedHour, selectedMinute) -> {

                    reminderCalendar.set(
                            Calendar.HOUR_OF_DAY,
                            selectedHour
                    );

                    reminderCalendar.set(
                            Calendar.MINUTE,
                            selectedMinute
                    );

                    reminderCalendar.set(Calendar.SECOND, 0);
                    reminderCalendar.set(Calendar.MILLISECOND, 0);

                    timeSelected = true;
                    updateReminderText();
                },
                hour,
                minute,
                false
        );

        dialog.show();
    }

    // Display selected reminder date and time
    private void updateReminderText() {

        SimpleDateFormat formatter = new SimpleDateFormat(
                "dd MMM yyyy, hh:mm a",
                Locale.getDefault()
        );

        txtReminderDateTime.setText(
                formatter.format(reminderCalendar.getTime())
        );
    }

    // Save or update note
    private void saveNote() {

        String title = edtTitle.getText().toString().trim();

        String description = edtDescription.getText()
                .toString().trim();

        String category = spinnerNoteCategory
                .getSelectedItem().toString();

        boolean pinned = checkPin.isChecked();

        boolean reminderEnabled = checkReminder.isChecked();

        // Validate title
        if (title.isEmpty()) {

            edtTitle.setError("Please enter a note title");
            edtTitle.requestFocus();
            return;
        }

        // Validate reminder date and time
        if (reminderEnabled && (!dateSelected || !timeSelected)) {

            Toast.makeText(
                    this,
                    "Please select reminder date and time",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        long reminderTime = reminderEnabled
                ? reminderCalendar.getTimeInMillis()
                : 0;

        // Check whether reminder time is in the future
        if (reminderEnabled
                && reminderTime <= System.currentTimeMillis()) {

            Toast.makeText(
                    this,
                    "Please select a future reminder time",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (existingNote == null) {

            // Create a new note
            long createdDate = System.currentTimeMillis();

            Note note = new Note(
                    title,
                    description,
                    category,
                    pinned,
                    createdDate,
                    reminderEnabled,
                    reminderTime
            );

            noteViewModel.insert(note);

            // Schedule reminder
            if (reminderEnabled) {
                AlarmScheduler.scheduleReminder(this, note);
            }

            Toast.makeText(
                    this,
                    "Note saved successfully",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

            // Cancel previous reminder
            AlarmScheduler.cancelReminder(this, existingNote);

            // Update existing note
            existingNote.setTitle(title);
            existingNote.setDescription(description);
            existingNote.setCategory(category);
            existingNote.setPinned(pinned);
            existingNote.setReminderEnabled(reminderEnabled);
            existingNote.setReminderTime(reminderTime);

            noteViewModel.update(existingNote);

            // Schedule updated reminder
            if (reminderEnabled) {
                AlarmScheduler.scheduleReminder(this, existingNote);
            }

            Toast.makeText(
                    this,
                    "Note updated successfully",
                    Toast.LENGTH_SHORT
            ).show();
        }

        setResult(Activity.RESULT_OK);
        finish();
    }
}
