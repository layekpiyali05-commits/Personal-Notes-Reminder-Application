
package com.example.personalnotesreminder.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.personalnotesreminder.model.Note;
import com.example.personalnotesreminder.repository.NoteRepository;

import java.util.List;

public class NoteViewModel extends AndroidViewModel {

    private final NoteRepository repository;

    private final LiveData<List<Note>> allNotes;

    public NoteViewModel(@NonNull Application application) {
        super(application);

        repository = new NoteRepository(application);

        allNotes = repository.getAllNotes();
    }

    // Get all notes
    public LiveData<List<Note>> getAllNotes() {
        return allNotes;
    }

    // Search notes
    public LiveData<List<Note>> searchNotes(String query) {
        return repository.searchNotes(query);
    }

    // Filter notes by category
    public LiveData<List<Note>> getNotesByCategory(String category) {
        return repository.getNotesByCategory(category);
    }

    // Insert a note
    public void insert(Note note) {
        repository.insert(note);
    }

    // Update a note
    public void update(Note note) {
        repository.update(note);
    }

    // Delete a note
    public void delete(Note note) {
        repository.delete(note);
    }

    // Delete all notes
    public void deleteAllNotes() {
        repository.deleteAllNotes();
    }
}
