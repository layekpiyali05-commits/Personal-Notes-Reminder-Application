
package com.example.personalnotesreminder.notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.personalnotesreminder.utils.NotificationHelper;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        String title = intent.getStringExtra("note_title");
        String description = intent.getStringExtra("note_description");

        int notificationId = intent.getIntExtra(
                "notification_id",
                100
        );

        if (title == null || title.trim().isEmpty()) {
            title = "Note Reminder";
        }

        if (description == null || description.trim().isEmpty()) {
            description = "You have a scheduled reminder.";
        }

        // Display the reminder notification
        NotificationHelper.createNotificationChannel(context);

        NotificationHelper.showNotification(
                context,
                notificationId,
                title,
                description
        );
    }
}
