
package com.example.personalnotesreminder.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.personalnotesreminder.R;
import com.example.personalnotesreminder.adapter.NoteAdapter;
import com.example.personalnotesreminder.model.Note;
import com.example.personalnotesreminder.notification.AlarmScheduler;
import com.example.personalnotesreminder.utils.NotificationHelper;
import com.example.personalnotesreminder.viewmodel.NoteViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerNotes;
    private EditText edtSearch;
    private Spinner spinnerCategory;
    private FloatingActionButton fabAddNote;

    private NoteAdapter noteAdapter;
    private NoteViewModel noteViewModel;

    private LiveData<List<Note>> currentNotes;

    private final String[] categories = {
            "All", "Personal", "Study", "Work", "Shopping", "Other"
    };

    // Request notification permission
    private final ActivityResultLauncher<String>
            notificationPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {

                        if (isGranted) {
                            Toast.makeText(
                                    this,
                                    "Notification permission granted",
                                    Toast.LENGTH_SHORT
                            ).show();
                        } else {
                            Toast.makeText(
                                    this,
                                    "Notification permission denied. Reminders may not appear.",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();

        noteViewModel = new ViewModelProvider(this)
                .get(NoteViewModel.class);

        setupRecyclerView();
        setupCategorySpinner();
        setupSearch();

        // Create notification channel
        NotificationHelper.createNotificationChannel(this);

        // Request notification permission
        requestNotificationPermission();

        // Add new note
        fabAddNote.setOnClickListener(v -> {

            Intent intent = new Intent(
                    MainActivity.this,
                    AddEditNoteActivity.class
            );

            startActivity(intent);
        });

        // Display all notes initially
        observeNotes(noteViewModel.getAllNotes());
    }

    // Request permission for Android 13 and above
    private void requestNotificationPermission() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED) {

                notificationPermissionLauncher.launch(
                        Manifest.permission.POST_NOTIFICATIONS
                );
            }
        }
    }

    // Initialize UI components
    private void initializeViews() {

        recyclerNotes = findViewById(R.id.recyclerNotes);
        edtSearch = findViewById(R.id.edtSearch);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        fabAddNote = findViewById(R.id.fabAddNote);
    }

    // Setup RecyclerView
    private void setupRecyclerView() {

        recyclerNotes.setLayoutManager(
                new LinearLayoutManager(this)
        );

        noteAdapter = new NoteAdapter(note -> {

            Intent intent = new Intent(
                    MainActivity.this,
                    AddEditNoteActivity.class
            );

            intent.putExtra("note", note);

            startActivity(intent);
        });

        recyclerNotes.setAdapter(noteAdapter);
    }

    // Setup category Spinner
    private void setupCategorySpinner() {

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                categories
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerCategory.setAdapter(adapter);

        spinnerCategory.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        applyFilters();
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent) {
                    }
                }
        );
    }

    // Setup search functionality
    private void setupSearch() {

        edtSearch.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(
                    CharSequence s,
                    int start,
                    int count,
                    int after) {
            }

            @Override
            public void onTextChanged(
                    CharSequence s,
                    int start,
                    int before,
                    int count) {

                applyFilters();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    // Apply search and category filters
    private void applyFilters() {

        String query = edtSearch.getText()
                .toString()
                .trim();

        String category = spinnerCategory.getSelectedItem()
                .toString();

        if (!query.isEmpty()) {

            observeNotes(noteViewModel.searchNotes(query));

        } else if (!category.equals("All")) {

            observeNotes(
                    noteViewModel.getNotesByCategory(category)
            );

        } else {

            observeNotes(noteViewModel.getAllNotes());
        }
    }

    // Observe note data
    private void observeNotes(LiveData<List<Note>> notesLiveData) {

        if (currentNotes != null) {
            currentNotes.removeObservers(this);
        }

        currentNotes = notesLiveData;

        currentNotes.observe(this, notes -> {
            noteAdapter.setNotes(notes);
        });
    }
}
