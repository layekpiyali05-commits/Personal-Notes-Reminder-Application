
package com.example.personalnotesreminder.model;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "notes")
public class Note implements java.io.Serializable {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String title;
    private String description;
    private String category;

    private boolean pinned;

    private long createdDate;

    private boolean reminderEnabled;
    private long reminderTime;

    // Default constructor required by Room
    public Note() {
    }

    // Constructor for creating a new note
    @Ignore
    public Note(String title, String description,
                String category, boolean pinned,
                long createdDate, boolean reminderEnabled,
                long reminderTime) {

        this.title = title;
        this.description = description;
        this.category = category;
        this.pinned = pinned;
        this.createdDate = createdDate;
        this.reminderEnabled = reminderEnabled;
        this.reminderTime = reminderTime;
    }

    // ID
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Title
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // Description
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Category
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    // Pin status
    public boolean isPinned() {
        return pinned;
    }

    public void setPinned(boolean pinned) {
        this.pinned = pinned;
    }

    // Created date
    public long getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(long createdDate) {
        this.createdDate = createdDate;
    }

    // Reminder status
    public boolean isReminderEnabled() {
        return reminderEnabled;
    }

    public void setReminderEnabled(boolean reminderEnabled) {
        this.reminderEnabled = reminderEnabled;
    }

    // Reminder time
    public long getReminderTime() {
        return reminderTime;
    }

    public void setReminderTime(long reminderTime) {
        this.reminderTime = reminderTime;
    }
}
