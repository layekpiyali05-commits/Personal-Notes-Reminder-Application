
package com.example.personalnotesreminder.notification;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.example.personalnotesreminder.model.Note;

public class AlarmScheduler {

    // Schedule a reminder
    public static void scheduleReminder(Context context, Note note) {

        if (note == null || !note.isReminderEnabled()) {
            return;
        }

        long reminderTime = note.getReminderTime();

        if (reminderTime <= System.currentTimeMillis()) {
            return;
        }

        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        if (alarmManager == null) {
            return;
        }

        Intent intent = new Intent(context, AlarmReceiver.class);

        intent.putExtra("note_title", note.getTitle());
        intent.putExtra("note_description", note.getDescription());
        intent.putExtra("notification_id", getNotificationId(note));

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                getNotificationId(note),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Schedule the reminder
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    reminderTime,
                    pendingIntent
            );

        } else {

            alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    reminderTime,
                    pendingIntent
            );
        }
    }

    // Cancel a scheduled reminder
    public static void cancelReminder(Context context, Note note) {

        if (note == null) {
            return;
        }

        Intent intent = new Intent(context, AlarmReceiver.class);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                getNotificationId(note),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager =
                (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        if (alarmManager != null) {
            alarmManager.cancel(pendingIntent);
        }
    }

    // Generate a unique notification ID
    private static int getNotificationId(Note note) {
        long createdDate = note.getCreatedDate();
        return (int) (createdDate ^ (createdDate >>> 32));
    }
}
