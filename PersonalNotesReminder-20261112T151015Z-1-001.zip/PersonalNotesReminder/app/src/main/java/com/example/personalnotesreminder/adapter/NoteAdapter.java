package com.example.personalnotesreminder.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.personalnotesreminder.R;
import com.example.personalnotesreminder.model.Note;

import java.util.ArrayList;
import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    private List<Note> noteList = new ArrayList<>();
    private final OnNoteClickListener listener;

    public interface OnNoteClickListener {
        void onNoteClick(Note note);
    }

    public NoteAdapter(OnNoteClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_note, parent, false);
        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull NoteViewHolder holder, int position) {
        Note note = noteList.get(position);

        holder.txtTitle.setText(note.getTitle());
        holder.txtDescription.setText(note.getDescription());
        holder.txtCategory.setText(note.getCategory());

        // Show/hide pin indicator icon
        if (note.isPinned()) {
            holder.imgPin.setVisibility(View.VISIBLE);
        } else {
            holder.imgPin.setVisibility(View.GONE);
        }

        // Show/hide reminder indicator
        if (note.isReminderEnabled()) {
            holder.txtReminderInfo.setVisibility(View.VISIBLE);
        } else {
            holder.txtReminderInfo.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onNoteClick(note);
            }
        });
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public void setNotes(List<Note> notes) {
        noteList = notes != null ? new ArrayList<>(notes) : new ArrayList<>();
        notifyDataSetChanged();
    }

    static class NoteViewHolder extends RecyclerView.ViewHolder {
        TextView txtTitle;
        TextView txtDescription;
        TextView txtCategory;
        ImageView imgPin;
        TextView txtReminderInfo;

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTitle = itemView.findViewById(R.id.txtTitle);
            txtDescription = itemView.findViewById(R.id.txtDescription);
            txtCategory = itemView.findViewById(R.id.txtCategory);
            imgPin = itemView.findViewById(R.id.imgPin);
            txtReminderInfo = itemView.findViewById(R.id.txtReminderInfo);
        }
    }
}
